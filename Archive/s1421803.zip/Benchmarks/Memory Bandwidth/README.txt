--- CREDIT ---

Benchmark used is STREAM written by John McCalpin
    https://www.cs.virginia.edu/stream/
    https://www.cs.virginia.edu/stream/FTP/Code/

Benchmark suite adapted from Karl Rupp's github repo and article:
    https://github.com/karlrupp/knl-stream-benchmark
    https://www.karlrupp.net/2016/07/knights-landing-vs-knights-corner-haswell-ivy-bridge-and-sandy-bridge-stream-benchmark-results/



--- USAGE ---

To Run:

    make
    ./run [ 0 | 1 ]         # 0 for DDR, 1 for MCDRAM