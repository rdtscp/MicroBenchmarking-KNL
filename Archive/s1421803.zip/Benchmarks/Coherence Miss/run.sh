#!/bin/bash

numactl -m 0 ./coherence_latencies.o $1 $2 $3 $4