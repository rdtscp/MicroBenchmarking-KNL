--- USAGE ---

To Run:

    make
    ./run [ 0 | 1 ]         # 0 for DDR, 1 for MCDRAM